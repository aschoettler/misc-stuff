const map = require("./lib/github-light.map.json")

module.exports = map
